
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
v
function preload(){
  
  
  monkey_running =   loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
 createCanvas(400,400) 

   monkey=createSprite(50,360,20,50)
   monkey.addAnimation("running", monkey_running)
   monkey.scale=0.1
  
   ground=createSprite(0,400,800,21)
   ground.velocityX=5
   ground.x = ground.width/2;
  
  invisibleGround = createSprite(0,400,800,21);
  invisibleGround.visible = true;
  
  obstaclesGroup=createGroup();
  bananaGroup=createGroup();
  
  obstacle=createSprite(200,355,50,50)
  obstacle.addImage(obstacleImage);
  obstacle.scale=0.2
}


function draw() {
background(255)
 
if (ground.x>800){
  ground.x= 400
}  
 
  if (keyDown("space")&& monkey.y>=60){
    monkey.velocityY=-5 
  }
  
drawSprites() 
}

function spawnObstacles(){
 if (frameRate % 300 === 0){
   obstacle.velocityX = -(6 + score/100);
   obstacle.addImage(obstacleImage);
    //generate random obstacles
    var rand = Math.round(random(1,6));
    switch(rand) {
      //case 1: obstacle.addImage(obstacle1);
             // break;
     // case 2: obstacle.addImage(obstacle2);
              //break;
      //case 3: obstacle.addImage(obstacle3);
              //break;
      //case 4: obstacle.addImage(obstacle4);
              //break;
      //case 5: obstacle.addImage(obstacle5);
              //break;
      //case 6: obstacle.addImage(obstacle6);
             // break;
      //default: break;
    }
 }
  obstacleGroup.add(obstacle)
}



